﻿Imports System.Data.OleDb
Public Class Floor
    Dim rdRooms As OleDbDataReader
    Private Function GetAllControls(ByVal control As Control) As IEnumerable(Of Control)
        Dim controls = control.Controls.Cast(Of Control)()
        Return controls.SelectMany(Function(ctrl) GetAllControls(ctrl)).Concat(controls)
    End Function

    Private Sub Floor_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        rdRooms = Database.GetRooms
        'Dim buttons = Me.GetAllControls(Me).OfType(Of Button)().ToList()
        'For Each btn As Button In buttons
        '    If rdRooms.HasRows Then
        '        If btn.AccessibleName.Equals(rdRooms.Item(0)) Then
        '            Dim listAttrib As New List(Of String)
        '            listAttrib.Add(rdRooms.Item(0))
        '            listAttrib.Add(rdRooms.Item(1))
        '            listAttrib.Add(rdRooms.Item(2))
        '            listAttrib.Add(rdRooms.Item(3))
        '            btn.Tag = listAttrib
        '        End If
        '    End If
        'Next
        Dim strt As String = Nothing
        If rdRooms.HasRows Then
            While rdRooms.Read
                strt = strt & rdRooms.Item(0).ToString & vbTab & rdRooms.Item(1).ToString & vbTab & rdRooms.Item(2) & vbNewLine
            End While
            'MessageBox.Show(strt)
        End If

        'AddHandler MyBase.MouseWheel, AddressOf mouseScrolled
    End Sub

    Private Sub Button1_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.MouseEnter, Button4.MouseEnter, Button3.MouseEnter, Button22.MouseEnter, Button21.MouseEnter, Button2.MouseEnter, Button15.MouseEnter, Button14.MouseEnter, Button13.MouseEnter, Button10.MouseEnter, Button1.MouseEnter
        Dim btnThis As Button = CType(sender, Button)
        Dim strRoomNum As String = Nothing
        Dim strFlrNo As String = Nothing
        Dim strRoomName As String = Nothing
        Dim strDesc As String = Nothing
        rdRooms = GetRoomsWhere("RoomNo=" & btnThis.AccessibleName)
        If rdRooms.HasRows Then
            While rdRooms.Read
                strRoomNum = rdRooms.Item(0).ToString
                strRoomName = rdRooms.Item(2).ToString
                strFlrNo = rdRooms.Item(1).ToString
                strDesc = rdRooms.Item(3).ToString
            End While
            ToolTip1.ToolTipTitle = If(strRoomName = Nothing, "Generic Room", strRoomName) & "(" & strRoomNum & ")"
            ToolTip1.Show("Floor no.: " & strFlrNo & vbNewLine & strDesc, btnThis)
        Else
            MsgBox("No such record")
        End If
    End Sub

    Private Sub Button10_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.MouseLeave, Button4.MouseLeave, Button3.MouseLeave, Button22.MouseLeave, Button21.MouseLeave, Button2.MouseLeave, Button15.MouseLeave, Button14.MouseLeave, Button13.MouseLeave, Button10.MouseLeave, Button1.MouseLeave
        Dim btnThis As Button = CType(sender, Button)
        ToolTip1.Hide(btnThis)
    End Sub

    Private Sub Floor_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles MyBase.Scroll
        Dim clRect As New Rectangle
        clRect = Me.Parent.ClientRectangle
        DetailsPane.Location = New Point(DetailsPane.Location.X, clRect.Location.Y)
    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click, Button4.Click, Button3.Click, Button22.Click, Button21.Click, Button2.Click, Button15.Click, Button14.Click, Button13.Click, Button10.Click, Button1.Click
        Dim btnThis As Button = CType(sender, Button)
        Dim strRoomNum As String = Nothing
        Dim strFlrNo As String = Nothing
        Dim strRoomName As String = Nothing
        Dim strDesc As String = Nothing
        rdRooms = GetRoomsWhere("RoomNo=" & btnThis.AccessibleName)

        If Me.ParentForm.WindowState = FormWindowState.Maximized Then
            If rdRooms.HasRows Then
                While rdRooms.Read
                    strRoomNum = rdRooms.Item(0).ToString
                    strRoomName = rdRooms.Item(2).ToString
                    strFlrNo = rdRooms.Item(1).ToString
                    strDesc = rdRooms.Item(3).ToString
                End While
                RoomName.Text = If(strRoomName = Nothing, "Generic Room", strRoomName) & "(" & strRoomNum & ")"
                FloorNumber.Text = "Floor No.: " & strFlrNo
                RoomDescription.Text = If(strDesc = Nothing, "No description available", strDesc)
            Else
                MsgBox("No such record")
            End If
        Else
            Dim dialog As New Dialog
            Dim sett As New RoomDetails

            If rdRooms.HasRows Then
                While rdRooms.Read
                    strRoomNum = rdRooms.Item(0).ToString
                    strRoomName = rdRooms.Item(2).ToString
                    strFlrNo = rdRooms.Item(1).ToString
                    strDesc = rdRooms.Item(3).ToString
                End While
                sett.RoomName.Text = If(strRoomName = Nothing, "Generic Room", strRoomName) & "(" & strRoomNum & ")"
                sett.FloorNumber.Text = "Floor No.: " & strFlrNo
                sett.RoomDescription.Text = If(strDesc = Nothing, "No description available", strDesc)
            Else
                MsgBox("No such record")
            End If

            dialog.Size = sett.Size
            dialog.Controls.Add(sett)
            dialog.StartPosition = FormStartPosition.CenterParent
            dialog.ShowInTaskbar = False

            dialog.ShowDialog()
            dialog.Focus()
        End If
    End Sub

    'Private Sub mouseScrolled(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Scroll

    'End Sub
End Class
