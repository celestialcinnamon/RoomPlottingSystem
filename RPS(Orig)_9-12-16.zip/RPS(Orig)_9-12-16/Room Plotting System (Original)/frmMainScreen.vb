﻿Imports System.Data.OleDb

Public Class frmMainScreen
    Private IsFormBeingDragged As Boolean = False 'Variable na magsasabi kung dina-drag ba ang form (para 'to sa movement ng form)
    Private MouseDownX As Integer 'Position sa X-Axis ng mouse pointer n'ong dina-drag niya ang Form
    Private MouseDownY As Integer 'Position sa Y-Axis ng mouse pointer n'ong dina-drag niya ang Form

    Private Sub frmMainScreen_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Sa load natin ise-set ang lahat ng defaults ng program :)

        pnlMenuContainer.Width = pnlMenuCollapser.Width
        pnlScreenContainer.Width += pnlMenuCollapsible.Width
        pnlScreenContainer.Location = New Point(pnlMenuContainer.Width, pnlScreenContainer.Location.Y)

        ScreenToday.BringToFront()
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseButton.Click
        Me.Close() 'Magsasara ang form
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles maxRes.Click
        If Me.WindowState.Equals(FormWindowState.Maximized) Then 'Kung naka-maximize ang form
            Me.WindowState = FormWindowState.Normal  'Ibalik sa normal size nito
        Else  'Kung hindi...
            Me.WindowState = FormWindowState.Maximized  'I-maximize ito
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles minimze.Click
        Me.WindowState = FormWindowState.Minimized  'I-minimize (maha-hide siya at pupunta sa taskbar
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkCollapser.CheckedChanged
        If chkCollapser.Checked Then  'chkCollapser -- ito 'yong button sa menu na may tatlong linya
            pnlMenuContainer.Width = pnlMenuCollapser.Width + pnlMenuCollapsible.Width  'lalaki lang lahat sa Menu para makita ng user
            pnlScreenContainer.Width -= pnlMenuCollapsible.Width
            pnlScreenContainer.Location = New Point(pnlMenuContainer.Width, pnlScreenContainer.Location.Y)

        Else
            pnlMenuContainer.Width = pnlMenuCollapser.Width

            pnlScreenContainer.Width += pnlMenuCollapsible.Width
            pnlScreenContainer.Location = New Point(pnlMenuContainer.Width, pnlScreenContainer.Location.Y)
        End If
    End Sub

    Private Sub Menu_Rooms_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Rooms.Click, Button1.Click
        ScreenRooms.BringToFront()  'Ipapakita 'yong panel na ScreenRooms kapag pinindot ang "Rooms" sa Menu Pane
        chkCollapser.Checked = False  'Naka-false, para kapag pinindot niya, magtatago ulit 'yong menu.
    End Sub

    Private Sub Label8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label8.Click
        'Sa label ko siya nilagay kasi para magkaroon ng HIDDEN FEATURE. Kapag pinindot ang Label sa Rooms, lalabas lahat ng rooms ng UCC sa isang Dialog box.

        Dim reader As OleDbDataReader  'Reader
        reader = Database.GetRooms   'Function 'to sa Database.vb. Kukunin niya lahat ng Rooms sa database. :D :)

        Dim str As String = Nothing

        If reader.HasRows Then
            While reader.Read
                str = str & reader.Item(0) & vbTab & reader.Item(1) &
                    vbTab & reader.Item(2) & vbTab & reader.Item(3) &
                    vbNewLine  'ia-assign niya lahat ng laman ng reader sa iisang String variable para ma-display sa MessageBox
            End While
        End If

        MessageBox.Show(str)  'Ito 'yong MessageBox na may lamang info tungkol sa tblRooms
    End Sub

    Private Sub BorderNorth_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles BorderNorth.MouseDown
        'Kapag imo-move ng user ang form. :D :)
        If e.Button = MouseButtons.Left Then  'Kung left click ang ginawa ng user

            'MouseDown ang event dito (hindi Click) kaya matatapos ang event na 'to kapag hindi na naka-hold ang left click...
            IsFormBeingDragged = True   'Kaya hangga't hindi inaangat ng user ang left mouse button, ibig sabihin dina-drag niya ang form.
            MouseDownX = e.X  'Nilalagay natin sa var na MouseDownX ang position ng mouse pointer n'ong nag-MouseDown ang user (e.X)
            MouseDownY = e.Y  'Nilalagay natin sa var na MouseDownY ang position ng mouse pointer n'ong nag-MouseDown ang user (e.Y)
        End If
    End Sub

    Private Sub BorderNorth_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles BorderNorth.MouseUp
        'Ito nga 'yong sabi ko kanina sa MouseDown. Kapag binitiwan ng user ang left mouse button, magti-trigger ang MouseUp event, kaya...

        If e.Button = MouseButtons.Left Then  'Kung left mouse button ang ni-release ng user
            IsFormBeingDragged = False  'Ibig sabihin, hindi na niya dina-drag ang form.
        End If
    End Sub

    Private Sub BorderNorth_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles BorderNorth.MouseMove
        'Ito ang event kapag gumalaw ang mouse habang naka-drag

        If IsFormBeingDragged Then   'So kapag naka-true ang IsFormBeingDragged, ibig sabihin, dina-drag ng user ang form kaya...
            Dim temp As Point = New Point()

            'Kung saan dadalhin ng user ang mouse pointer, doon pupunta ang form.
            temp.X = Me.Location.X + (e.X - MouseDownX)
            temp.Y = Me.Location.Y + (e.Y - MouseDownY)
            Me.Location = temp
            temp = Nothing
        End If

        'Kung may tanong ka rito, kausapin mo lang ako. xD :D :D :)
    End Sub

    Private Sub frmMainScreen_Resize(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        'Ito naman, para sa napakalupit kong problema na nagre-resize 'yong form, pero 'yong isang panel hindi.
        'Ito na, na-solve ko na. :D

        FloorContainer1.Size = New Size(ScreenRooms.Width - 210, FloorContainer1.Height)
    End Sub

    Private Sub OvalShape1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape1.Click
        ScreenToday.BringToFront()  'Kapag pinindot ang picture ng UCC, lalabas ang Today
    End Sub

    Private Sub cmdSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSettings.Click
        'Ito sa settings. Wala pang laman. :D 

        Dim dialog As New Dialog
        Dim sett As New Settings
        If Me.WindowState = FormWindowState.Maximized Then
            dialog.Size = New Size(949, 676)
        Else
            dialog.Size = New Size(517, 491)
        End If

        dialog.Controls.Add(sett)
        dialog.StartPosition = FormStartPosition.CenterParent
        dialog.ShowInTaskbar = False

        dialog.ShowDialog()
        dialog.Focus()
    End Sub

    Private Sub NumericUpDown4_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown4.ValueChanged
        Dim i As Integer = NumericUpDown4.Value
        Select Case i
            Case 1
                FloorNo1.BringToFront()
            Case 2
                FloorNo2.BringToFront()
            Case 3
                FloorNo3.BringToFront()
            Case 4
                FloorNo4.BringToFront()
            Case 5
                FloorNo5.BringToFront()
        End Select
    End Sub
End Class
