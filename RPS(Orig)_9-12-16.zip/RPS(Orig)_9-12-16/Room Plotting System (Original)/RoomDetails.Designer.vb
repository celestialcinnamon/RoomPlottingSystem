﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RoomDetails
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DetailsPane = New System.Windows.Forms.Panel()
        Me.CloseButton = New System.Windows.Forms.Button()
        Me.RoomDescription = New System.Windows.Forms.Label()
        Me.rmDesc = New System.Windows.Forms.Label()
        Me.NextClass = New System.Windows.Forms.Label()
        Me.AvailabilityInMinutes = New System.Windows.Forms.Label()
        Me.FloorNumber = New System.Windows.Forms.Label()
        Me.RoomName = New System.Windows.Forms.Label()
        Me.DetailsPane.SuspendLayout()
        Me.SuspendLayout()
        '
        'DetailsPane
        '
        Me.DetailsPane.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.DetailsPane.Controls.Add(Me.CloseButton)
        Me.DetailsPane.Controls.Add(Me.RoomDescription)
        Me.DetailsPane.Controls.Add(Me.rmDesc)
        Me.DetailsPane.Controls.Add(Me.NextClass)
        Me.DetailsPane.Controls.Add(Me.AvailabilityInMinutes)
        Me.DetailsPane.Controls.Add(Me.FloorNumber)
        Me.DetailsPane.Controls.Add(Me.RoomName)
        Me.DetailsPane.Location = New System.Drawing.Point(0, 0)
        Me.DetailsPane.Name = "DetailsPane"
        Me.DetailsPane.Size = New System.Drawing.Size(666, 510)
        Me.DetailsPane.TabIndex = 13
        '
        'CloseButton
        '
        Me.CloseButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CloseButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.CloseButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.CloseButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.CloseButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(5, Byte), Integer), CType(CType(5, Byte), Integer))
        Me.CloseButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CloseButton.Font = New System.Drawing.Font("Microsoft YaHei UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CloseButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.CloseButton.Location = New System.Drawing.Point(630, -1)
        Me.CloseButton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.Size = New System.Drawing.Size(35, 38)
        Me.CloseButton.TabIndex = 14
        Me.CloseButton.Text = "×"
        Me.CloseButton.UseVisualStyleBackColor = False
        '
        'RoomDescription
        '
        Me.RoomDescription.AutoSize = True
        Me.RoomDescription.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RoomDescription.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RoomDescription.Location = New System.Drawing.Point(33, 177)
        Me.RoomDescription.Name = "RoomDescription"
        Me.RoomDescription.Size = New System.Drawing.Size(95, 18)
        Me.RoomDescription.TabIndex = 0
        Me.RoomDescription.Text = "Room Desc:"
        '
        'rmDesc
        '
        Me.rmDesc.AutoSize = True
        Me.rmDesc.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rmDesc.ForeColor = System.Drawing.SystemColors.ControlText
        Me.rmDesc.Location = New System.Drawing.Point(33, 158)
        Me.rmDesc.Name = "rmDesc"
        Me.rmDesc.Size = New System.Drawing.Size(104, 19)
        Me.rmDesc.TabIndex = 0
        Me.rmDesc.Text = "Room Desc:"
        '
        'NextClass
        '
        Me.NextClass.AutoSize = True
        Me.NextClass.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NextClass.ForeColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer))
        Me.NextClass.Location = New System.Drawing.Point(33, 91)
        Me.NextClass.Name = "NextClass"
        Me.NextClass.Size = New System.Drawing.Size(277, 24)
        Me.NextClass.TabIndex = 0
        Me.NextClass.Text = "Next Class in This Room: {0}"
        '
        'AvailabilityInMinutes
        '
        Me.AvailabilityInMinutes.AutoSize = True
        Me.AvailabilityInMinutes.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AvailabilityInMinutes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer))
        Me.AvailabilityInMinutes.Location = New System.Drawing.Point(164, 44)
        Me.AvailabilityInMinutes.Name = "AvailabilityInMinutes"
        Me.AvailabilityInMinutes.Size = New System.Drawing.Size(244, 24)
        Me.AvailabilityInMinutes.TabIndex = 0
        Me.AvailabilityInMinutes.Text = "Available in {0} minutes..."
        '
        'FloorNumber
        '
        Me.FloorNumber.AutoSize = True
        Me.FloorNumber.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FloorNumber.ForeColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer))
        Me.FloorNumber.Location = New System.Drawing.Point(33, 44)
        Me.FloorNumber.Name = "FloorNumber"
        Me.FloorNumber.Size = New System.Drawing.Size(96, 24)
        Me.FloorNumber.TabIndex = 0
        Me.FloorNumber.Text = "Floor No."
        '
        'RoomName
        '
        Me.RoomName.AutoSize = True
        Me.RoomName.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RoomName.Location = New System.Drawing.Point(33, 20)
        Me.RoomName.Name = "RoomName"
        Me.RoomName.Size = New System.Drawing.Size(133, 24)
        Me.RoomName.TabIndex = 0
        Me.RoomName.Text = "Room Name"
        '
        'RoomDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Controls.Add(Me.DetailsPane)
        Me.Name = "RoomDetails"
        Me.Size = New System.Drawing.Size(666, 511)
        Me.DetailsPane.ResumeLayout(False)
        Me.DetailsPane.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DetailsPane As System.Windows.Forms.Panel
    Friend WithEvents RoomDescription As System.Windows.Forms.Label
    Friend WithEvents rmDesc As System.Windows.Forms.Label
    Friend WithEvents NextClass As System.Windows.Forms.Label
    Friend WithEvents AvailabilityInMinutes As System.Windows.Forms.Label
    Friend WithEvents FloorNumber As System.Windows.Forms.Label
    Friend WithEvents RoomName As System.Windows.Forms.Label
    Friend WithEvents CloseButton As System.Windows.Forms.Button

End Class
