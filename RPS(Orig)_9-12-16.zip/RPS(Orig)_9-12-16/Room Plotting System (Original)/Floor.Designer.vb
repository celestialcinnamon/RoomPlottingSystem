﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Floor
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.DetailsPane = New System.Windows.Forms.Panel()
        Me.RoomDescription = New System.Windows.Forms.Label()
        Me.rmDesc = New System.Windows.Forms.Label()
        Me.NextClass = New System.Windows.Forms.Label()
        Me.AvailabilityInMinutes = New System.Windows.Forms.Label()
        Me.FloorNumber = New System.Windows.Forms.Label()
        Me.RoomName = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.DetailsPane.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.AccessibleName = "1"
        Me.Button1.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue
        Me.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Tomato
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Location = New System.Drawing.Point(3, 3)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(203, 115)
        Me.Button1.TabIndex = 0
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button13
        '
        Me.Button13.AccessibleName = "2"
        Me.Button13.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button13.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue
        Me.Button13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.Button13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Tomato
        Me.Button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button13.Location = New System.Drawing.Point(254, 3)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(203, 115)
        Me.Button13.TabIndex = 0
        Me.Button13.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.AccessibleName = "5"
        Me.Button2.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button2.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue
        Me.Button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.Button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Tomato
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Location = New System.Drawing.Point(3, 233)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(203, 115)
        Me.Button2.TabIndex = 1
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button14
        '
        Me.Button14.AccessibleName = "6"
        Me.Button14.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button14.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue
        Me.Button14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.Button14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Tomato
        Me.Button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button14.Location = New System.Drawing.Point(254, 233)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(203, 115)
        Me.Button14.TabIndex = 1
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.AccessibleName = "7"
        Me.Button3.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue
        Me.Button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.Button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Tomato
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Location = New System.Drawing.Point(3, 348)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(203, 115)
        Me.Button3.TabIndex = 2
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button15
        '
        Me.Button15.AccessibleName = "8"
        Me.Button15.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button15.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue
        Me.Button15.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.Button15.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Tomato
        Me.Button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button15.Location = New System.Drawing.Point(254, 348)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(203, 115)
        Me.Button15.TabIndex = 2
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.AccessibleName = "11"
        Me.Button4.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button4.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue
        Me.Button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.Button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Tomato
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Location = New System.Drawing.Point(3, 578)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(203, 115)
        Me.Button4.TabIndex = 3
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.AccessibleName = "3"
        Me.Button9.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button9.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue
        Me.Button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.Button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Tomato
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.Location = New System.Drawing.Point(3, 118)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(203, 115)
        Me.Button9.TabIndex = 8
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button21
        '
        Me.Button21.AccessibleName = "4"
        Me.Button21.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button21.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue
        Me.Button21.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.Button21.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Tomato
        Me.Button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button21.Location = New System.Drawing.Point(254, 118)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(203, 115)
        Me.Button21.TabIndex = 8
        Me.Button21.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.AccessibleName = "9"
        Me.Button10.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button10.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue
        Me.Button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.Button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Tomato
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button10.Location = New System.Drawing.Point(3, 463)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(203, 115)
        Me.Button10.TabIndex = 9
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button22
        '
        Me.Button22.AccessibleName = "10"
        Me.Button22.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button22.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue
        Me.Button22.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.Button22.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Tomato
        Me.Button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button22.Location = New System.Drawing.Point(254, 463)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(203, 115)
        Me.Button22.TabIndex = 9
        Me.Button22.UseVisualStyleBackColor = False
        '
        'DetailsPane
        '
        Me.DetailsPane.Controls.Add(Me.RoomDescription)
        Me.DetailsPane.Controls.Add(Me.rmDesc)
        Me.DetailsPane.Controls.Add(Me.NextClass)
        Me.DetailsPane.Controls.Add(Me.AvailabilityInMinutes)
        Me.DetailsPane.Controls.Add(Me.FloorNumber)
        Me.DetailsPane.Controls.Add(Me.RoomName)
        Me.DetailsPane.Location = New System.Drawing.Point(493, 3)
        Me.DetailsPane.Name = "DetailsPane"
        Me.DetailsPane.Size = New System.Drawing.Size(927, 702)
        Me.DetailsPane.TabIndex = 12
        '
        'RoomDescription
        '
        Me.RoomDescription.AutoSize = True
        Me.RoomDescription.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RoomDescription.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RoomDescription.Location = New System.Drawing.Point(33, 177)
        Me.RoomDescription.Name = "RoomDescription"
        Me.RoomDescription.Size = New System.Drawing.Size(95, 18)
        Me.RoomDescription.TabIndex = 0
        Me.RoomDescription.Text = "Room Desc:"
        '
        'rmDesc
        '
        Me.rmDesc.AutoSize = True
        Me.rmDesc.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rmDesc.ForeColor = System.Drawing.SystemColors.ControlText
        Me.rmDesc.Location = New System.Drawing.Point(33, 158)
        Me.rmDesc.Name = "rmDesc"
        Me.rmDesc.Size = New System.Drawing.Size(104, 19)
        Me.rmDesc.TabIndex = 0
        Me.rmDesc.Text = "Room Desc:"
        '
        'NextClass
        '
        Me.NextClass.AutoSize = True
        Me.NextClass.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NextClass.ForeColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer))
        Me.NextClass.Location = New System.Drawing.Point(33, 91)
        Me.NextClass.Name = "NextClass"
        Me.NextClass.Size = New System.Drawing.Size(277, 24)
        Me.NextClass.TabIndex = 0
        Me.NextClass.Text = "Next Class in This Room: {0}"
        '
        'AvailabilityInMinutes
        '
        Me.AvailabilityInMinutes.AutoSize = True
        Me.AvailabilityInMinutes.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AvailabilityInMinutes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer))
        Me.AvailabilityInMinutes.Location = New System.Drawing.Point(164, 44)
        Me.AvailabilityInMinutes.Name = "AvailabilityInMinutes"
        Me.AvailabilityInMinutes.Size = New System.Drawing.Size(244, 24)
        Me.AvailabilityInMinutes.TabIndex = 0
        Me.AvailabilityInMinutes.Text = "Available in {0} minutes..."
        '
        'FloorNumber
        '
        Me.FloorNumber.AutoSize = True
        Me.FloorNumber.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FloorNumber.ForeColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer))
        Me.FloorNumber.Location = New System.Drawing.Point(33, 44)
        Me.FloorNumber.Name = "FloorNumber"
        Me.FloorNumber.Size = New System.Drawing.Size(96, 24)
        Me.FloorNumber.TabIndex = 0
        Me.FloorNumber.Text = "Floor No."
        '
        'RoomName
        '
        Me.RoomName.AutoSize = True
        Me.RoomName.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RoomName.Location = New System.Drawing.Point(33, 20)
        Me.RoomName.Name = "RoomName"
        Me.RoomName.Size = New System.Drawing.Size(133, 24)
        Me.RoomName.TabIndex = 0
        Me.RoomName.Text = "Room Name"
        '
        'Floor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Controls.Add(Me.DetailsPane)
        Me.Controls.Add(Me.Button22)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Floor"
        Me.Size = New System.Drawing.Size(1423, 721)
        Me.DetailsPane.ResumeLayout(False)
        Me.DetailsPane.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents DetailsPane As System.Windows.Forms.Panel
    Friend WithEvents RoomName As System.Windows.Forms.Label
    Friend WithEvents RoomDescription As System.Windows.Forms.Label
    Friend WithEvents rmDesc As System.Windows.Forms.Label
    Friend WithEvents NextClass As System.Windows.Forms.Label
    Friend WithEvents AvailabilityInMinutes As System.Windows.Forms.Label
    Friend WithEvents FloorNumber As System.Windows.Forms.Label
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip

End Class
