﻿Public Class Dialog

End Class