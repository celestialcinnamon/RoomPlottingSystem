﻿Public Class Settings
    Private Sub CloseButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseButton.Click
        Me.ParentForm.Close()

    End Sub

    Private Sub Settings_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Leave
        Me.ParentForm.Close()
    End Sub

    Private Sub Settings_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If frmMainScreen.WindowState = FormWindowState.Maximized Then
            Me.Size = New Size(949, 676)
        Else
            Me.Size = New Size(517, 491)
        End If
    End Sub
End Class
