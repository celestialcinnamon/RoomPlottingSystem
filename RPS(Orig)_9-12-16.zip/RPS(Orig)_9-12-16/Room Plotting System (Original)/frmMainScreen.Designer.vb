﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMainScreen
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.LineShape3 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.BorderRight = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape1 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.BorderNorth = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.CloseButton = New System.Windows.Forms.Button()
        Me.maxRes = New System.Windows.Forms.Button()
        Me.minimze = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pnlBanner = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ShapeContainer2 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.OvalShape1 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.pnlInteractiveContainer = New System.Windows.Forms.Panel()
        Me.pnlScreenContainer = New System.Windows.Forms.Panel()
        Me.ScreenToday = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.minFlr1 = New System.Windows.Forms.Panel()
        Me.minFlr2 = New System.Windows.Forms.Panel()
        Me.minFlr3 = New System.Windows.Forms.Panel()
        Me.minFlr4 = New System.Windows.Forms.Panel()
        Me.minFlr5 = New System.Windows.Forms.Panel()
        Me.minFlr0 = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.NumericUpDown3 = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.NumericUpDown2 = New System.Windows.Forms.NumericUpDown()
        Me.grpbxAvailNow = New System.Windows.Forms.GroupBox()
        Me.RoomContainer = New System.Windows.Forms.Panel()
        Me.Flr0 = New System.Windows.Forms.Panel()
        Me.Flr5 = New System.Windows.Forms.Panel()
        Me.Flr4 = New System.Windows.Forms.Panel()
        Me.Flr3 = New System.Windows.Forms.Panel()
        Me.Flr2 = New System.Windows.Forms.Panel()
        Me.Flr1 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.lblToday = New System.Windows.Forms.Label()
        Me.ScreenRooms = New System.Windows.Forms.Panel()
        Me.FloorContainer1 = New System.Windows.Forms.Panel()
        Me.FloorNo5 = New System.Windows.Forms.Panel()
        Me.FloorNo4 = New System.Windows.Forms.Panel()
        Me.FloorNo3 = New System.Windows.Forms.Panel()
        Me.FloorNo2 = New System.Windows.Forms.Panel()
        Me.FloorNo1 = New System.Windows.Forms.Panel()
        Me.Floor1 = New Room_Plotting_System__Original_.Floor()
        Me.NumericUpDown4 = New System.Windows.Forms.NumericUpDown()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.pnlMenuContainer = New System.Windows.Forms.Panel()
        Me.pnlMenuCollapsible = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Menu_Sections = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Menu_Rooms = New System.Windows.Forms.Button()
        Me.pnlMenuCollapser = New System.Windows.Forms.Panel()
        Me.cmdSettings = New System.Windows.Forms.Button()
        Me.chkCollapser = New System.Windows.Forms.CheckBox()
        Me.pnlBanner.SuspendLayout()
        Me.pnlInteractiveContainer.SuspendLayout()
        Me.pnlScreenContainer.SuspendLayout()
        Me.ScreenToday.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpbxAvailNow.SuspendLayout()
        Me.RoomContainer.SuspendLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ScreenRooms.SuspendLayout()
        Me.FloorContainer1.SuspendLayout()
        Me.FloorNo1.SuspendLayout()
        CType(Me.NumericUpDown4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlMenuContainer.SuspendLayout()
        Me.pnlMenuCollapsible.SuspendLayout()
        Me.pnlMenuCollapser.SuspendLayout()
        Me.SuspendLayout()
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1, Me.LineShape3, Me.BorderRight, Me.LineShape1, Me.BorderNorth})
        Me.ShapeContainer1.Size = New System.Drawing.Size(703, 612)
        Me.ShapeContainer1.TabIndex = 0
        Me.ShapeContainer1.TabStop = False
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BackColor = System.Drawing.Color.Crimson
        Me.RectangleShape1.FillColor = System.Drawing.Color.DodgerBlue
        Me.RectangleShape1.FillGradientColor = System.Drawing.Color.RoyalBlue
        Me.RectangleShape1.FillGradientStyle = Microsoft.VisualBasic.PowerPacks.FillGradientStyle.Vertical
        Me.RectangleShape1.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid
        Me.RectangleShape1.Location = New System.Drawing.Point(6, 0)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(85, 39)
        '
        'LineShape3
        '
        Me.LineShape3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LineShape3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.LineShape3.BorderWidth = 10
        Me.LineShape3.Name = "LineShape3"
        Me.LineShape3.X1 = 0
        Me.LineShape3.X2 = 703
        Me.LineShape3.Y1 = 612
        Me.LineShape3.Y2 = 612
        '
        'BorderRight
        '
        Me.BorderRight.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BorderRight.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.BorderRight.BorderWidth = 10
        Me.BorderRight.Name = "BorderRight"
        Me.BorderRight.X1 = 703
        Me.BorderRight.X2 = 703
        Me.BorderRight.Y1 = 0
        Me.BorderRight.Y2 = 612
        '
        'LineShape1
        '
        Me.LineShape1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.LineShape1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.LineShape1.BorderWidth = 10
        Me.LineShape1.Name = "LineShape1"
        Me.LineShape1.X1 = 0
        Me.LineShape1.X2 = 0
        Me.LineShape1.Y1 = 0
        Me.LineShape1.Y2 = 612
        '
        'BorderNorth
        '
        Me.BorderNorth.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BorderNorth.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.BorderNorth.BorderWidth = 79
        Me.BorderNorth.Name = "BorderNorth"
        Me.BorderNorth.X1 = 0
        Me.BorderNorth.X2 = 703
        Me.BorderNorth.Y1 = 0
        Me.BorderNorth.Y2 = 0
        '
        'CloseButton
        '
        Me.CloseButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CloseButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.CloseButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.CloseButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.CloseButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(5, Byte), Integer), CType(CType(5, Byte), Integer))
        Me.CloseButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CloseButton.Font = New System.Drawing.Font("Microsoft YaHei UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CloseButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.CloseButton.Location = New System.Drawing.Point(663, 0)
        Me.CloseButton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.Size = New System.Drawing.Size(35, 38)
        Me.CloseButton.TabIndex = 1
        Me.CloseButton.Text = "×"
        Me.CloseButton.UseVisualStyleBackColor = False
        '
        'maxRes
        '
        Me.maxRes.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.maxRes.BackColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.maxRes.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.maxRes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue
        Me.maxRes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue
        Me.maxRes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.maxRes.Font = New System.Drawing.Font("Microsoft YaHei UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.maxRes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.maxRes.Location = New System.Drawing.Point(623, 0)
        Me.maxRes.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.maxRes.Name = "maxRes"
        Me.maxRes.Size = New System.Drawing.Size(35, 38)
        Me.maxRes.TabIndex = 2
        Me.maxRes.Text = "□   "
        Me.maxRes.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.maxRes.UseVisualStyleBackColor = False
        '
        'minimze
        '
        Me.minimze.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.minimze.BackColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.minimze.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.minimze.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue
        Me.minimze.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue
        Me.minimze.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.minimze.Font = New System.Drawing.Font("Microsoft YaHei UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.minimze.ForeColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.minimze.Location = New System.Drawing.Point(583, 0)
        Me.minimze.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.minimze.Name = "minimze"
        Me.minimze.Size = New System.Drawing.Size(35, 38)
        Me.minimze.TabIndex = 2
        Me.minimze.Text = "―"
        Me.minimze.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.minimze.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("Microsoft YaHei UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(100, 10)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(240, 19)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Room Plotter *Hindi* Premium"
        '
        'pnlBanner
        '
        Me.pnlBanner.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlBanner.BackColor = System.Drawing.Color.Transparent
        Me.pnlBanner.Controls.Add(Me.Label3)
        Me.pnlBanner.Controls.Add(Me.Label2)
        Me.pnlBanner.Controls.Add(Me.ShapeContainer2)
        Me.pnlBanner.Location = New System.Drawing.Point(4, 38)
        Me.pnlBanner.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.pnlBanner.Name = "pnlBanner"
        Me.pnlBanner.Size = New System.Drawing.Size(695, 95)
        Me.pnlBanner.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft YaHei UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(95, 55)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(147, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "{0} Rooms in Total"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft YaHei UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(95, 27)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(297, 26)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "University of Caloocan City"
        '
        'ShapeContainer2
        '
        Me.ShapeContainer2.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer2.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer2.Name = "ShapeContainer2"
        Me.ShapeContainer2.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.OvalShape1})
        Me.ShapeContainer2.Size = New System.Drawing.Size(695, 95)
        Me.ShapeContainer2.TabIndex = 0
        Me.ShapeContainer2.TabStop = False
        '
        'OvalShape1
        '
        Me.OvalShape1.BackgroundImage = Global.Room_Plotting_System__Original_.My.Resources.Resources.ucc_official_logo1
        Me.OvalShape1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.OvalShape1.FillColor = System.Drawing.Color.DodgerBlue
        Me.OvalShape1.FillGradientColor = System.Drawing.Color.RoyalBlue
        Me.OvalShape1.FillGradientStyle = Microsoft.VisualBasic.PowerPacks.FillGradientStyle.Vertical
        Me.OvalShape1.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid
        Me.OvalShape1.Location = New System.Drawing.Point(8, 9)
        Me.OvalShape1.Name = "OvalShape1"
        Me.OvalShape1.Size = New System.Drawing.Size(75, 75)
        '
        'pnlInteractiveContainer
        '
        Me.pnlInteractiveContainer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlInteractiveContainer.Controls.Add(Me.pnlScreenContainer)
        Me.pnlInteractiveContainer.Controls.Add(Me.pnlMenuContainer)
        Me.pnlInteractiveContainer.Location = New System.Drawing.Point(5, 133)
        Me.pnlInteractiveContainer.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.pnlInteractiveContainer.Name = "pnlInteractiveContainer"
        Me.pnlInteractiveContainer.Size = New System.Drawing.Size(693, 474)
        Me.pnlInteractiveContainer.TabIndex = 5
        '
        'pnlScreenContainer
        '
        Me.pnlScreenContainer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlScreenContainer.Controls.Add(Me.ScreenToday)
        Me.pnlScreenContainer.Controls.Add(Me.ScreenRooms)
        Me.pnlScreenContainer.Location = New System.Drawing.Point(36, 0)
        Me.pnlScreenContainer.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.pnlScreenContainer.Name = "pnlScreenContainer"
        Me.pnlScreenContainer.Size = New System.Drawing.Size(656, 474)
        Me.pnlScreenContainer.TabIndex = 1
        '
        'ScreenToday
        '
        Me.ScreenToday.AutoScroll = True
        Me.ScreenToday.Controls.Add(Me.GroupBox1)
        Me.ScreenToday.Controls.Add(Me.grpbxAvailNow)
        Me.ScreenToday.Controls.Add(Me.lblToday)
        Me.ScreenToday.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ScreenToday.Location = New System.Drawing.Point(0, 0)
        Me.ScreenToday.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.ScreenToday.Name = "ScreenToday"
        Me.ScreenToday.Size = New System.Drawing.Size(656, 474)
        Me.ScreenToday.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.Panel2)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.NumericUpDown3)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.NumericUpDown2)
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox1.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(5, 214)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(647, 176)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Rooms Available In..."
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.minFlr1)
        Me.Panel2.Controls.Add(Me.minFlr2)
        Me.Panel2.Controls.Add(Me.minFlr3)
        Me.Panel2.Controls.Add(Me.minFlr4)
        Me.Panel2.Controls.Add(Me.minFlr5)
        Me.Panel2.Controls.Add(Me.minFlr0)
        Me.Panel2.Location = New System.Drawing.Point(32, 64)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(382, 95)
        Me.Panel2.TabIndex = 2
        '
        'minFlr1
        '
        Me.minFlr1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.minFlr1.Location = New System.Drawing.Point(0, 0)
        Me.minFlr1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.minFlr1.Name = "minFlr1"
        Me.minFlr1.Size = New System.Drawing.Size(382, 95)
        Me.minFlr1.TabIndex = 5
        '
        'minFlr2
        '
        Me.minFlr2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.minFlr2.Location = New System.Drawing.Point(0, 0)
        Me.minFlr2.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.minFlr2.Name = "minFlr2"
        Me.minFlr2.Size = New System.Drawing.Size(382, 95)
        Me.minFlr2.TabIndex = 4
        '
        'minFlr3
        '
        Me.minFlr3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.minFlr3.Location = New System.Drawing.Point(0, 0)
        Me.minFlr3.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.minFlr3.Name = "minFlr3"
        Me.minFlr3.Size = New System.Drawing.Size(382, 95)
        Me.minFlr3.TabIndex = 3
        '
        'minFlr4
        '
        Me.minFlr4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.minFlr4.Location = New System.Drawing.Point(0, 0)
        Me.minFlr4.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.minFlr4.Name = "minFlr4"
        Me.minFlr4.Size = New System.Drawing.Size(382, 95)
        Me.minFlr4.TabIndex = 2
        '
        'minFlr5
        '
        Me.minFlr5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.minFlr5.Location = New System.Drawing.Point(0, 0)
        Me.minFlr5.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.minFlr5.Name = "minFlr5"
        Me.minFlr5.Size = New System.Drawing.Size(382, 95)
        Me.minFlr5.TabIndex = 1
        '
        'minFlr0
        '
        Me.minFlr0.Dock = System.Windows.Forms.DockStyle.Fill
        Me.minFlr0.Location = New System.Drawing.Point(0, 0)
        Me.minFlr0.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.minFlr0.Name = "minFlr0"
        Me.minFlr0.Size = New System.Drawing.Size(382, 95)
        Me.minFlr0.TabIndex = 0
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(140, 33)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(46, 20)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Floor:"
        '
        'NumericUpDown3
        '
        Me.NumericUpDown3.Location = New System.Drawing.Point(187, 31)
        Me.NumericUpDown3.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.NumericUpDown3.Maximum = New Decimal(New Integer() {5, 0, 0, 0})
        Me.NumericUpDown3.Name = "NumericUpDown3"
        Me.NumericUpDown3.Size = New System.Drawing.Size(34, 26)
        Me.NumericUpDown3.TabIndex = 0
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(76, 33)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 20)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Minutes"
        '
        'NumericUpDown2
        '
        Me.NumericUpDown2.Increment = New Decimal(New Integer() {5, 0, 0, 0})
        Me.NumericUpDown2.Location = New System.Drawing.Point(37, 31)
        Me.NumericUpDown2.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.NumericUpDown2.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
        Me.NumericUpDown2.Name = "NumericUpDown2"
        Me.NumericUpDown2.Size = New System.Drawing.Size(34, 26)
        Me.NumericUpDown2.TabIndex = 0
        '
        'grpbxAvailNow
        '
        Me.grpbxAvailNow.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpbxAvailNow.Controls.Add(Me.RoomContainer)
        Me.grpbxAvailNow.Controls.Add(Me.Label4)
        Me.grpbxAvailNow.Controls.Add(Me.NumericUpDown1)
        Me.grpbxAvailNow.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.grpbxAvailNow.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpbxAvailNow.Location = New System.Drawing.Point(5, 32)
        Me.grpbxAvailNow.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.grpbxAvailNow.Name = "grpbxAvailNow"
        Me.grpbxAvailNow.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.grpbxAvailNow.Size = New System.Drawing.Size(647, 176)
        Me.grpbxAvailNow.TabIndex = 1
        Me.grpbxAvailNow.TabStop = False
        Me.grpbxAvailNow.Text = "Rooms Available Now..."
        '
        'RoomContainer
        '
        Me.RoomContainer.Controls.Add(Me.Flr0)
        Me.RoomContainer.Controls.Add(Me.Flr5)
        Me.RoomContainer.Controls.Add(Me.Flr4)
        Me.RoomContainer.Controls.Add(Me.Flr3)
        Me.RoomContainer.Controls.Add(Me.Flr2)
        Me.RoomContainer.Controls.Add(Me.Flr1)
        Me.RoomContainer.Location = New System.Drawing.Point(32, 64)
        Me.RoomContainer.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RoomContainer.Name = "RoomContainer"
        Me.RoomContainer.Size = New System.Drawing.Size(382, 95)
        Me.RoomContainer.TabIndex = 2
        '
        'Flr0
        '
        Me.Flr0.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Flr0.Location = New System.Drawing.Point(0, 0)
        Me.Flr0.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Flr0.Name = "Flr0"
        Me.Flr0.Size = New System.Drawing.Size(382, 95)
        Me.Flr0.TabIndex = 5
        '
        'Flr5
        '
        Me.Flr5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Flr5.Location = New System.Drawing.Point(0, 0)
        Me.Flr5.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Flr5.Name = "Flr5"
        Me.Flr5.Size = New System.Drawing.Size(382, 95)
        Me.Flr5.TabIndex = 4
        '
        'Flr4
        '
        Me.Flr4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Flr4.Location = New System.Drawing.Point(0, 0)
        Me.Flr4.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Flr4.Name = "Flr4"
        Me.Flr4.Size = New System.Drawing.Size(382, 95)
        Me.Flr4.TabIndex = 3
        '
        'Flr3
        '
        Me.Flr3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Flr3.Location = New System.Drawing.Point(0, 0)
        Me.Flr3.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Flr3.Name = "Flr3"
        Me.Flr3.Size = New System.Drawing.Size(382, 95)
        Me.Flr3.TabIndex = 2
        '
        'Flr2
        '
        Me.Flr2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Flr2.Location = New System.Drawing.Point(0, 0)
        Me.Flr2.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Flr2.Name = "Flr2"
        Me.Flr2.Size = New System.Drawing.Size(382, 95)
        Me.Flr2.TabIndex = 1
        '
        'Flr1
        '
        Me.Flr1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Flr1.Location = New System.Drawing.Point(0, 0)
        Me.Flr1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Flr1.Name = "Flr1"
        Me.Flr1.Size = New System.Drawing.Size(382, 95)
        Me.Flr1.TabIndex = 0
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(29, 33)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(46, 20)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Floor:"
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(81, 31)
        Me.NumericUpDown1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.NumericUpDown1.Maximum = New Decimal(New Integer() {5, 0, 0, 0})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(34, 26)
        Me.NumericUpDown1.TabIndex = 0
        '
        'lblToday
        '
        Me.lblToday.AutoSize = True
        Me.lblToday.Font = New System.Drawing.Font("Microsoft YaHei UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblToday.Location = New System.Drawing.Point(5, 3)
        Me.lblToday.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblToday.Name = "lblToday"
        Me.lblToday.Size = New System.Drawing.Size(95, 26)
        Me.lblToday.TabIndex = 0
        Me.lblToday.Text = "Today..."
        '
        'ScreenRooms
        '
        Me.ScreenRooms.AutoScroll = True
        Me.ScreenRooms.Controls.Add(Me.FloorContainer1)
        Me.ScreenRooms.Controls.Add(Me.NumericUpDown4)
        Me.ScreenRooms.Controls.Add(Me.Label10)
        Me.ScreenRooms.Controls.Add(Me.Label9)
        Me.ScreenRooms.Controls.Add(Me.Label8)
        Me.ScreenRooms.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ScreenRooms.Location = New System.Drawing.Point(0, 0)
        Me.ScreenRooms.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.ScreenRooms.Name = "ScreenRooms"
        Me.ScreenRooms.Size = New System.Drawing.Size(656, 474)
        Me.ScreenRooms.TabIndex = 3
        '
        'FloorContainer1
        '
        Me.FloorContainer1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FloorContainer1.AutoScroll = True
        Me.FloorContainer1.AutoScrollMinSize = New System.Drawing.Size(560, 275)
        Me.FloorContainer1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.FloorContainer1.Controls.Add(Me.FloorNo5)
        Me.FloorContainer1.Controls.Add(Me.FloorNo4)
        Me.FloorContainer1.Controls.Add(Me.FloorNo3)
        Me.FloorContainer1.Controls.Add(Me.FloorNo2)
        Me.FloorContainer1.Controls.Add(Me.FloorNo1)
        Me.FloorContainer1.Location = New System.Drawing.Point(5, 84)
        Me.FloorContainer1.Name = "FloorContainer1"
        Me.FloorContainer1.Size = New System.Drawing.Size(1788, 404)
        Me.FloorContainer1.TabIndex = 4
        '
        'FloorNo5
        '
        Me.FloorNo5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FloorNo5.Location = New System.Drawing.Point(0, 0)
        Me.FloorNo5.Name = "FloorNo5"
        Me.FloorNo5.Size = New System.Drawing.Size(1788, 404)
        Me.FloorNo5.TabIndex = 3
        '
        'FloorNo4
        '
        Me.FloorNo4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FloorNo4.Location = New System.Drawing.Point(0, 0)
        Me.FloorNo4.Name = "FloorNo4"
        Me.FloorNo4.Size = New System.Drawing.Size(1788, 404)
        Me.FloorNo4.TabIndex = 3
        '
        'FloorNo3
        '
        Me.FloorNo3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FloorNo3.Location = New System.Drawing.Point(0, 0)
        Me.FloorNo3.Name = "FloorNo3"
        Me.FloorNo3.Size = New System.Drawing.Size(1788, 404)
        Me.FloorNo3.TabIndex = 2
        '
        'FloorNo2
        '
        Me.FloorNo2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FloorNo2.Location = New System.Drawing.Point(0, 0)
        Me.FloorNo2.Name = "FloorNo2"
        Me.FloorNo2.Size = New System.Drawing.Size(1788, 404)
        Me.FloorNo2.TabIndex = 1
        '
        'FloorNo1
        '
        Me.FloorNo1.Controls.Add(Me.Floor1)
        Me.FloorNo1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FloorNo1.Location = New System.Drawing.Point(0, 0)
        Me.FloorNo1.Name = "FloorNo1"
        Me.FloorNo1.Size = New System.Drawing.Size(1788, 404)
        Me.FloorNo1.TabIndex = 1
        '
        'Floor1
        '
        Me.Floor1.AccessibleName = "1"
        Me.Floor1.AutoScroll = True
        Me.Floor1.AutoScrollMinSize = New System.Drawing.Size(1, 1)
        Me.Floor1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Floor1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Floor1.Location = New System.Drawing.Point(0, 0)
        Me.Floor1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Floor1.Name = "Floor1"
        Me.Floor1.Size = New System.Drawing.Size(1788, 404)
        Me.Floor1.TabIndex = 0
        '
        'NumericUpDown4
        '
        Me.NumericUpDown4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown4.Location = New System.Drawing.Point(122, 52)
        Me.NumericUpDown4.Maximum = New Decimal(New Integer() {5, 0, 0, 0})
        Me.NumericUpDown4.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown4.Name = "NumericUpDown4"
        Me.NumericUpDown4.Size = New System.Drawing.Size(43, 26)
        Me.NumericUpDown4.TabIndex = 3
        Me.NumericUpDown4.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(31, 55)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(85, 19)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Floor No.:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(30, 32)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(493, 18)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "Select a floor number, and the available rooms will be displayed below."
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(6, 9)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(82, 24)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Rooms"
        '
        'pnlMenuContainer
        '
        Me.pnlMenuContainer.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.pnlMenuContainer.Controls.Add(Me.pnlMenuCollapsible)
        Me.pnlMenuContainer.Controls.Add(Me.pnlMenuCollapser)
        Me.pnlMenuContainer.Location = New System.Drawing.Point(0, 0)
        Me.pnlMenuContainer.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.pnlMenuContainer.Name = "pnlMenuContainer"
        Me.pnlMenuContainer.Size = New System.Drawing.Size(36, 474)
        Me.pnlMenuContainer.TabIndex = 0
        '
        'pnlMenuCollapsible
        '
        Me.pnlMenuCollapsible.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.pnlMenuCollapsible.BackColor = System.Drawing.Color.Tomato
        Me.pnlMenuCollapsible.Controls.Add(Me.Button2)
        Me.pnlMenuCollapsible.Controls.Add(Me.Menu_Sections)
        Me.pnlMenuCollapsible.Controls.Add(Me.Button1)
        Me.pnlMenuCollapsible.Controls.Add(Me.Menu_Rooms)
        Me.pnlMenuCollapsible.Location = New System.Drawing.Point(36, 0)
        Me.pnlMenuCollapsible.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.pnlMenuCollapsible.Name = "pnlMenuCollapsible"
        Me.pnlMenuCollapsible.Size = New System.Drawing.Size(208, 474)
        Me.pnlMenuCollapsible.TabIndex = 2
        '
        'Button2
        '
        Me.Button2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button2.FlatAppearance.BorderColor = System.Drawing.Color.Tomato
        Me.Button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DodgerBlue
        Me.Button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Button2.Location = New System.Drawing.Point(0, 98)
        Me.Button2.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(208, 48)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Subjects"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Menu_Sections
        '
        Me.Menu_Sections.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Menu_Sections.FlatAppearance.BorderColor = System.Drawing.Color.Tomato
        Me.Menu_Sections.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DodgerBlue
        Me.Menu_Sections.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue
        Me.Menu_Sections.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Menu_Sections.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Menu_Sections.ForeColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Menu_Sections.Location = New System.Drawing.Point(0, 51)
        Me.Menu_Sections.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Menu_Sections.Name = "Menu_Sections"
        Me.Menu_Sections.Size = New System.Drawing.Size(208, 48)
        Me.Menu_Sections.TabIndex = 2
        Me.Menu_Sections.Text = "Sections"
        Me.Menu_Sections.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.Tomato
        Me.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DodgerBlue
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Button1.Image = Global.Room_Plotting_System__Original_.My.Resources.Resources.settings_white_36x36
        Me.Button1.Location = New System.Drawing.Point(-34, 96)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(32, 40)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "ksdfdjkf"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Menu_Rooms
        '
        Me.Menu_Rooms.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Menu_Rooms.FlatAppearance.BorderColor = System.Drawing.Color.Tomato
        Me.Menu_Rooms.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DodgerBlue
        Me.Menu_Rooms.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue
        Me.Menu_Rooms.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Menu_Rooms.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Menu_Rooms.ForeColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Menu_Rooms.Location = New System.Drawing.Point(0, 3)
        Me.Menu_Rooms.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Menu_Rooms.Name = "Menu_Rooms"
        Me.Menu_Rooms.Size = New System.Drawing.Size(208, 48)
        Me.Menu_Rooms.TabIndex = 1
        Me.Menu_Rooms.Text = "Rooms"
        Me.Menu_Rooms.UseVisualStyleBackColor = True
        '
        'pnlMenuCollapser
        '
        Me.pnlMenuCollapser.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.pnlMenuCollapser.BackColor = System.Drawing.Color.Tomato
        Me.pnlMenuCollapser.Controls.Add(Me.cmdSettings)
        Me.pnlMenuCollapser.Controls.Add(Me.chkCollapser)
        Me.pnlMenuCollapser.Location = New System.Drawing.Point(0, 0)
        Me.pnlMenuCollapser.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.pnlMenuCollapser.Name = "pnlMenuCollapser"
        Me.pnlMenuCollapser.Size = New System.Drawing.Size(36, 474)
        Me.pnlMenuCollapser.TabIndex = 1
        '
        'cmdSettings
        '
        Me.cmdSettings.FlatAppearance.BorderColor = System.Drawing.Color.Tomato
        Me.cmdSettings.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DodgerBlue
        Me.cmdSettings.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue
        Me.cmdSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdSettings.ForeColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.cmdSettings.Image = Global.Room_Plotting_System__Original_.My.Resources.Resources.settings_white_36x36
        Me.cmdSettings.Location = New System.Drawing.Point(-8, 40)
        Me.cmdSettings.Name = "cmdSettings"
        Me.cmdSettings.Size = New System.Drawing.Size(54, 38)
        Me.cmdSettings.TabIndex = 6
        Me.cmdSettings.UseVisualStyleBackColor = True
        '
        'chkCollapser
        '
        Me.chkCollapser.Appearance = System.Windows.Forms.Appearance.Button
        Me.chkCollapser.AutoSize = True
        Me.chkCollapser.BackColor = System.Drawing.Color.Tomato
        Me.chkCollapser.FlatAppearance.BorderColor = System.Drawing.Color.Tomato
        Me.chkCollapser.FlatAppearance.CheckedBackColor = System.Drawing.Color.Tomato
        Me.chkCollapser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DodgerBlue
        Me.chkCollapser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue
        Me.chkCollapser.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkCollapser.Font = New System.Drawing.Font("Microsoft YaHei UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkCollapser.ForeColor = System.Drawing.Color.White
        Me.chkCollapser.Image = Global.Room_Plotting_System__Original_.My.Resources.Resources.menu_white_36x36
        Me.chkCollapser.Location = New System.Drawing.Point(-4, -2)
        Me.chkCollapser.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.chkCollapser.Name = "chkCollapser"
        Me.chkCollapser.Size = New System.Drawing.Size(42, 42)
        Me.chkCollapser.TabIndex = 1
        Me.chkCollapser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.chkCollapser.UseVisualStyleBackColor = False
        '
        'frmMainScreen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(703, 612)
        Me.Controls.Add(Me.pnlInteractiveContainer)
        Me.Controls.Add(Me.pnlBanner)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.minimze)
        Me.Controls.Add(Me.maxRes)
        Me.Controls.Add(Me.CloseButton)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmMainScreen"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Room Plotter"
        Me.pnlBanner.ResumeLayout(False)
        Me.pnlBanner.PerformLayout()
        Me.pnlInteractiveContainer.ResumeLayout(False)
        Me.pnlScreenContainer.ResumeLayout(False)
        Me.ScreenToday.ResumeLayout(False)
        Me.ScreenToday.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpbxAvailNow.ResumeLayout(False)
        Me.grpbxAvailNow.PerformLayout()
        Me.RoomContainer.ResumeLayout(False)
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ScreenRooms.ResumeLayout(False)
        Me.ScreenRooms.PerformLayout()
        Me.FloorContainer1.ResumeLayout(False)
        Me.FloorNo1.ResumeLayout(False)
        CType(Me.NumericUpDown4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlMenuContainer.ResumeLayout(False)
        Me.pnlMenuCollapsible.ResumeLayout(False)
        Me.pnlMenuCollapser.ResumeLayout(False)
        Me.pnlMenuCollapser.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents LineShape3 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents BorderRight As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents LineShape1 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents BorderNorth As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents CloseButton As System.Windows.Forms.Button
    Friend WithEvents maxRes As System.Windows.Forms.Button
    Friend WithEvents minimze As System.Windows.Forms.Button
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents pnlBanner As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ShapeContainer2 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents OvalShape1 As Microsoft.VisualBasic.PowerPacks.OvalShape
    Friend WithEvents pnlInteractiveContainer As System.Windows.Forms.Panel
    Friend WithEvents pnlMenuContainer As System.Windows.Forms.Panel
    Friend WithEvents pnlMenuCollapser As System.Windows.Forms.Panel
    Friend WithEvents chkCollapser As System.Windows.Forms.CheckBox
    Friend WithEvents pnlMenuCollapsible As System.Windows.Forms.Panel
    Friend WithEvents Menu_Rooms As System.Windows.Forms.Button
    Friend WithEvents pnlScreenContainer As System.Windows.Forms.Panel
    Friend WithEvents ScreenToday As System.Windows.Forms.Panel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents minFlr1 As System.Windows.Forms.Panel
    Friend WithEvents minFlr2 As System.Windows.Forms.Panel
    Friend WithEvents minFlr3 As System.Windows.Forms.Panel
    Friend WithEvents minFlr4 As System.Windows.Forms.Panel
    Friend WithEvents minFlr5 As System.Windows.Forms.Panel
    Friend WithEvents minFlr0 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents grpbxAvailNow As System.Windows.Forms.GroupBox
    Friend WithEvents RoomContainer As System.Windows.Forms.Panel
    Friend WithEvents Flr0 As System.Windows.Forms.Panel
    Friend WithEvents Flr5 As System.Windows.Forms.Panel
    Friend WithEvents Flr4 As System.Windows.Forms.Panel
    Friend WithEvents Flr3 As System.Windows.Forms.Panel
    Friend WithEvents Flr2 As System.Windows.Forms.Panel
    Friend WithEvents Flr1 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblToday As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Menu_Sections As System.Windows.Forms.Button
    Friend WithEvents ScreenRooms As System.Windows.Forms.Panel
    Friend WithEvents NumericUpDown4 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents FloorContainer1 As System.Windows.Forms.Panel
    Friend WithEvents Floor1 As Room_Plotting_System__Original_.Floor
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents cmdSettings As System.Windows.Forms.Button
    Friend WithEvents FloorNo1 As System.Windows.Forms.Panel
    Friend WithEvents FloorNo5 As System.Windows.Forms.Panel
    Friend WithEvents FloorNo4 As System.Windows.Forms.Panel
    Friend WithEvents FloorNo3 As System.Windows.Forms.Panel
    Friend WithEvents FloorNo2 As System.Windows.Forms.Panel

End Class
