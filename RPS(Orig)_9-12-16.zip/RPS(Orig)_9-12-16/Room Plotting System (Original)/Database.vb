﻿Imports System.Data.OleDb
Module Database

    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0; " &
        "Data Source=" & Application.StartupPath & "/CaseStudy.accdb"
    Public Connection As New OleDbConnection(connectionString)

    'Pag true, success ang connection. Else hindi.
    Public Function Load() As Boolean
        Dim bool As Boolean
        If Connection.State = ConnectionState.Closed Then
            Connection.Open()
            bool = True
        Else
            bool = False
        End If
        Return bool
    End Function


    Public Function GetRooms()
        If Connection.State = ConnectionState.Closed Then
            Connection.Open()
        End If

        Dim sql As String = "SELECT * FROM tblRooms"
        Dim sel As New OleDbCommand(sql, Connection)

        Dim reader As OleDbDataReader
        reader = sel.ExecuteReader

        Return reader
    End Function

    Public Function GetRoomsWhere(ByVal strConditions As String)
        If Connection.State = ConnectionState.Closed Then
            Connection.Open()
        End If

        Dim sql As String = "SELECT * FROM tblRooms WHERE " & strConditions
        Dim sel As New OleDbCommand(sql, Connection)

        Dim reader As OleDbDataReader
        reader = sel.ExecuteReader

        Return reader
    End Function
End Module
